package enums;

public enum BinderType {
    NON_CURATED, PAUPER, RARES, LUXURY, COLLECTOR
}
