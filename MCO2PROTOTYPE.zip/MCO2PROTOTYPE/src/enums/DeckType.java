package enums;

public enum DeckType {
    NORMAL, SELLABLE
}
