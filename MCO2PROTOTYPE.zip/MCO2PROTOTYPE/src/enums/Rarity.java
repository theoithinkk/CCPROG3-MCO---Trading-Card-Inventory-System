package enums;

public enum Rarity {
    COMMON, UNCOMMON, RARE, LEGENDARY
}
