package controller;

import model.*;
import enums.*;
import view.*;
import javax.swing.*;
import java.awt.*;

public class DeckController  extends ContainerController{
	public DeckController(TradingCardInventorySystem tcis, TCISGUI gui) {
		super(tcis, gui);
	}
}
