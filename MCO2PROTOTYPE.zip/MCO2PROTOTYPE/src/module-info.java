/**
 * 
 */
/**
 * 
 */
module MCO2PROTOTYPE {
	requires java.desktop;
}