package model;

public interface Tradeable {
	boolean isTradeable();
}
