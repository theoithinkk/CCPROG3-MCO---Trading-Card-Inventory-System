package model;

public interface Sellable {
	boolean isSellable();
	double getTotalValue();
}
