package model;

public class Collection extends CardContainer {
    public Collection() {
        super("Main Collection", Integer.MAX_VALUE);
    }
}
