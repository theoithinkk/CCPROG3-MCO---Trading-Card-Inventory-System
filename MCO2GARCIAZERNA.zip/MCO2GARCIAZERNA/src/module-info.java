/**
 * 
 */
/**
 * 
 */
module MCO2GARCIAZERNA {
	requires java.desktop;
}